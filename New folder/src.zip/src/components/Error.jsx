import React from "react";

const Error = () => {
  return <div>Internal Server Error</div>;
};

export default Error;
