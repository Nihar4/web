const { ExecuteQuery } = require("../../../utils/ExecuteQuery");

const InsertStrategy = async (id, strategyName, description, asset_class_name, stock, percentage) => {
    return new Promise(async (resolve, reject) => {


        const query = 'INSERT INTO strategy (id, name, description, asset_class_name, stock, percentage) VALUES (?, ?, ?, ?, ?, ?)';
        const params = [id, strategyName, description, asset_class_name, stock, percentage];

        try {
            const data = await ExecuteQuery(query, params);
            resolve(data);
        } catch (error) {
            reject(error);
        }
    });
};

module.exports = { InsertStrategy };
