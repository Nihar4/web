const { AddStrategyController, GetAllStrategiesController, DeleteStrategyController, GetStrategyController } = require("./controllers/StrategyManagement");

const StrategyManagement = require("express").Router()



StrategyManagement.post("/insert", AddStrategyController)
StrategyManagement.get("/get", GetAllStrategiesController)
StrategyManagement.get("/getone", GetStrategyController)
StrategyManagement.delete("/", DeleteStrategyController)








exports.StrategyManagement = StrategyManagement;