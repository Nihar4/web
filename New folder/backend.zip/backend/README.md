# swiftfoliosUK-API
Enables seamless access to real-time financial data and portfolio management functionalities
